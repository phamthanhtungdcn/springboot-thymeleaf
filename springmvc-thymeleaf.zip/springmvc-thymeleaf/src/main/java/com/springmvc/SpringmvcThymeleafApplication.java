package com.springmvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringmvcThymeleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringmvcThymeleafApplication.class, args);
	}

}
